const imagenes = [
  "https://images.pexels.com/photos/338713/pexels-photo-338713.jpeg",
  
  "https://images.pexels.com/photos/342971/pexels-photo-342971.jpeg",
  
  "https://images.pexels.com/photos/2775860/pexels-photo-2775860.jpeg",
  
  "https://images.pexels.com/photos/1200348/pexels-photo-1200348.jpeg",
  
  "https://images.pexels.com/photos/3323682/pexels-photo-3323682.jpeg",
  "https://images.pexels.com/photos/2995333/pexels-photo-2995333.jpeg"
];

//Seleccion de elementos // 

const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

//evento del click//
boton.addEventListener("click", () => {
 
 //lo siguiente es para que avance la foto //
  indice++;

//el siguiente if es para que cuando llegue al final se regrese al inicio//
  
  if (indice >= imagenes.length) {
    indice = 0;
  }
      // Cambiar imagen y texto //
imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});